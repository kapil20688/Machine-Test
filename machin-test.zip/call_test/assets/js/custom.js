/***************** Custom Jquery File *****************/
jQuery.noConflict();
jQuery(document).ready(function(){
	var base_url = jQuery('.base_url').val();
	jQuery(document).on('click', '.quetion', function(){
		jQuery('.form-submit').removeAttr('disabled');
		var counter = parseInt(jQuery('.general-html').find('.counter').text());
		jQuery('.general-html').find('.counter').text(counter+1);
		var general_html = jQuery('.general-html').html();
		jQuery('.call-form .inner-html').append(general_html);
	});

	jQuery(document).on('change', '.select-answer-type', function(){
		var names = 'answer-question[]';
		var multi_choice = 'multi-choice';
		var subQuestion = '<div class="sub-quetion"><i class="fa fa-plus"></i> Add Sub Question</div>';
		if(jQuery(this).hasClass('subquestion')){
			names = 'answer-subquestion[]';
			multi_choice = 'multi-choice-sub';
			subQuestion = '';
		}
		var html = ''
		switch(jQuery(this).val()){
			case '1':
			html = '<textarea class="form-control answer-question" name="'+names+'"></textarea>';
			break;
			case '2':
			html = '<input class="form-control answer-question" name="'+names+'" type="text">'+subQuestion+'<div class="sub-question-area"></div>';
			break;
			case '3':
			html = '<input class="answer-question form-control '+multi_choice+'" type="text">'+subQuestion+'<div class="sub-question-area"></div><input class=" answer-question form-control '+multi_choice+'" type="text">'+subQuestion+'<div class="sub-question-area"></div><input class="answer-question form-control '+multi_choice+'" type="text">'+subQuestion+'<div class="sub-question-area"></div><input class="answer-question form-control '+multi_choice+'" type="text">'+subQuestion+'<div class="sub-question-area"></div><input class="answer-question form-control '+multi_choice+'" type="text">'+subQuestion+'<div class="sub-question-area"></div><input class="form-control" name="'+names+'" type="hidden">';
			break;
			default:
			html = '';
			break;
		}
		jQuery(this).parent().parent().prev().find('.questions-child').html('').append(html);
	});
	
	jQuery(document).on('click', '.sub-quetion', function(){
		jQuery(this).parent('.questions-child').parent('.form-group').find('.parent-child-relation').val(parseInt(jQuery(this).parent('.questions-child').parent('.form-group').find('.parent-child-relation').val())+1);
		var general_html = jQuery('.general-html-subquestion').html();
		jQuery(this).next('.sub-question-area').append(general_html);
	});

	jQuery(document).on('change', '.multi-choice', function(){
		var choice = jQuery(this).val();
		var old_ansewr = jQuery(this).parent('div.questions-child').find('input[name="answer-question[]"]').val();
		if(choice!= ''){
			jQuery(this).parent('div.questions-child').find('input[name="answer-question[]"]').val(old_ansewr+','+choice);
		}
	});
	
	jQuery(document).on('change', '.multi-choice-sub', function(){
		var choice = jQuery(this).val();
		var old_ansewr = jQuery(this).parent('div.questions-child').find('input[name="answer-subquestion[]"]').val();
		if(choice != ''){
			jQuery(this).parent('div.questions-child').find('input[name="answer-subquestion[]"]').val(old_ansewr+','+choice);
		}
	});
	
	jQuery('.form-submit').click(function(){
		var check = 0;
		jQuery('.error-msg').remove();
		jQuery('.error').removeClass('error');
		jQuery('form.form-inline').find('.questions').each(function(){
			if(jQuery(this).val() == ''){
				check = 1;
				jQuery(this).parent('div.form-group').append('<span class="error-msg">Please fill the questions value.</span>');
				jQuery(this).addClass('error');
			}
		});	
		jQuery('form.form-inline').find('.select-answer-type').each(function(){
			if(jQuery(this).val() == ''){
				check = 1;
				jQuery(this).parent('div.form-group').append('<span class="error-msg">Please select answer type.</span>');
				jQuery(this).addClass('error');
			}
		});	
		jQuery('form.form-inline').find('.sub-questions').each(function(){
			if(jQuery(this).val() == ''){
				check = 1;
				jQuery(this).parent('div.form-group').append('<span class="error-msg">Please fill the questions value.</span>');
				jQuery(this).addClass('error');
			}
		});		
		if(check==1){
			return false;
		}else{
			jQuery('form.call-form').submit();
		}
	});
	
	jQuery(document).on('focus', '.questions', function(){
		jQuery(this).parent('div.form-group').find('.error-msg').remove();
		jQuery(this).removeClass('error');
	});
	
	jQuery(document).on('change', '.select-answer-type', function(){
		jQuery(this).parent('div.form-group').find('.error-msg').remove();
		jQuery(this).removeClass('error');
	});
	 
});
