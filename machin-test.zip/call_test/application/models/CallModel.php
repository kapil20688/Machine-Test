<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CallModel extends CI_Model{

	function __construct(){    
		parent::__construct();
	}


	/******************************** Dynamic Functuions **************************************/ 
    /*
     * this function insert data in to database tabel on basis of tabel name and data. 
     */
     
	function insertData($tabel_name, $data) {
		$this->db->insert($tabel_name, $data);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}
}