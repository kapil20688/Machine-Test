<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Call extends CI_Controller {

	function __construct() {
		parent::__construct();
	}
	
	public function makeCall(){
		$data['title'] = 'Make Call';
		$this->load->view('make_call_process', $data);	
	}
	
	public function processQuestion(){
		$counter = count($this->input->post('questions'));
		$has_child = 0;
		for($i = 0; $i<$counter; $i++){
			$answer = implode(',', array_filter(explode(',', $this->input->post('answer-question')[$i])));
			$data = array(
				'question' => $this->input->post('questions')[$i],
				'answer' => $answer,
			);
			$insert_id = $this->CallModel->insertData('parent_question_answer', $data);
			
			if($this->input->post('parent-child-relation')[$i] > 0){
				for($j=0; $j<$this->input->post('parent-child-relation')[$i]; $j++){
					$this->subQuestionProcess($insert_id, $has_child);
					$has_child++;
				}
			}
		}
		$this->session->set_flashdata('message', 'You have added call succesfully');
		redirect('makeCall');
	}
	
	public function subQuestionProcess($insert_id, $index){
		$answer = implode(',', array_filter(explode(',', $this->input->post('answer-subquestion')[$index])));
		$data = array(
			'question' => $this->input->post('sub-questions')[$index],
			'answer' => $answer,
			'parent' => $insert_id
		);
		$insert_id = $this->CallModel->insertData('child_question_answer', $data);
	}
	
}
