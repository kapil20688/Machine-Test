<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php echo $title; ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
		<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet"
		
		<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
		
	</head>
	<body>
		
		<div class="container">
			<div class="row">
				<div class="hidden-varible">
					<input type="hidden" class="base_url" value="<?php echo base_url(); ?>">
					<div class="general-html hide">
						<div class="row">
							<div class="col-1">
								<div class="question-number text-center"><span class="counter">0</span></div>
							</div>
							<div class="col-7">
								<div class="form-group">
									<input class="form-control questions" name="questions[]" type="text">
									<input type="hidden" class="parent-child-relation" name="parent-child-relation[]" value="0" />
									<div class="questions-child"></div>
								</div>
							</div>	
							<div class="col-4">
								<div class="form-group">
									<select class="form-control select-answer-type">
										<option value="">Select</option>
										<option value="1">Multi-line text</option>
										<option value="2">Single choice</option>
										<option value="3">Multiple choice</option>
									</select>
								</div>
							</div>	
						</div>	
					</div>
					<div class="general-html-subquestion hide">
						<div class="row">
							<div class="col-1"></div>
							<div class="col-7">
								<div class="form-group">
									<input class="form-control sub-questions" name="sub-questions[]" type="text">
									<!--<input type="hidden" class="parent-child-relation" name="parent-child-relation-sub[]" value="0" />-->
									<div class="questions-child"></div>
								</div>
							</div>	
							<div class="col-4">
								<div class="form-group">
									<select class="form-control select-answer-type subquestion">
										<option value="">Select</option>
										<option value="1">Multi-line text</option>
										<option value="2">Single choice</option>
										<option value="3">Multiple choice</option>
									</select>
								</div>
							</div>	
						</div>	
					</div>
				</div>
				<div class="col-md-12 col-sm-12">
					<div class="make-call-container">
						<?php
						if($this->session->flashdata('message')){ ?>
							<div class="alert alert-success">
								<strong>Success!</strong><?php echo $this->session->flashdata('message'); ?>.
							</div>
						<?php } ?>
						<div class="header">
							<h3>Add New Call</h3>
						</div>
						<div class="horizonel-line"><hr /></div>
						<div class="call-content">
							<form class="form-inline call-form" id="formid" method="post" action="<?php echo base_url(); ?>processQuestion">
								<div class="inner-html">
								
								</div>	
							</form>
						</div>
						<div class="make-call">
							<div class="col-md-2 offset-md-10">
								<div class="quetion"><i class="fa fa-plus"></i> Add new Question</div>
							</div>
						</div>
						<div class="horizonel-line"><hr /></div>
						<div class="footer">
							 <button type="button" class="btn btn-info form-submit" disabled>Submit</button>
							 <button type="button" class="btn btn-default" onclick="document.getElementById('formid').reset();">Cancel</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
