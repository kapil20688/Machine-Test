<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php echo $title; ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
		<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet"
		
		<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
		
	</head>
	<body>
		
		<div class="container">
			<div class="row">
				<div class="hidden-varible">
					<input type="hidden" class="base_url" value="<?php echo base_url(); ?>">
				</div>
				<div class="col-md-12 col-sm-12">
					<div class="make-call-container">
						<div class="header">
							<h3>Add New Call</h3>
						</div>
						<div class="horizonel-line"><hr /></div>
						<div class="call-content">
							
						</div>
						<div class="make-call">
							<div class="col-md-2 offset-md-10">
								<div class="quetion"><i class="fa fa-plus"></i> Add new Question</div>
							</div>
						</div>
						<div class="horizonel-line"><hr /></div>
						<div class="footer">
							 <button type="button" class="btn btn-info">Submit</button>
							 <button type="button" class="btn btn-default">Cancel</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
